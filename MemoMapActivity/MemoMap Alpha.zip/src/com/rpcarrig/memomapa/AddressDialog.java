package com.rpcarrig.memomapa;

import android.app.Dialog;
import android.content.Context;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;

public class AddressDialog extends Dialog implements OnClickListener {

	Button okButton;

	public AddressDialog(Context context) {
		super(context);
		setContentView(R.layout.activity_address_search);
		okButton = (Button) findViewById(R.id.but_OK);
		okButton.setOnClickListener(this);
	}

	@Override
	public void onClick(View v) {
		/** When OK Button is clicked, dismiss the dialog */
		if (v == okButton)
			dismiss();
	}

}