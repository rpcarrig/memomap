package com.rpcarrig.memomapa;

import android.app.Activity;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import android.os.Bundle;
import android.os.IBinder;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.TextView;
import android.widget.Toast;

import com.rpcarrig.memomapa.GpsService.GpsBinder;

public class CreateMemoActivity extends Activity {
	boolean 
		gpsBound = false;
	Double 
		lat,
		lon;
	int rad;	
	
	GpsService gpsService;
	TextView 
		longitude, 
		latitude;
	
	private ServiceConnection serviceConnection = new ServiceConnection(){
		@Override
		public void onServiceConnected(ComponentName name, IBinder service){
			GpsBinder binder = (GpsBinder)service;
			
			gpsService = binder.getService();
			gpsBound = true;
			
			Log.d("ServiceConnection", "onServiceConnected");
			
			lat = gpsService.getLatitude();
			lon = gpsService.getLongitude();
			
			TextView 
				longitude = (TextView) findViewById(R.id.tv_LongitudeValue),
				latitude = (TextView) findViewById(R.id.tv_LatitudeValue);
			longitude.setText(lon.toString());
			latitude.setText(lat.toString());
		}

		@Override
		public void onServiceDisconnected(ComponentName name) {
			gpsBound = false;
		}
	};
	
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_creatememo);
		
		Intent gpsIntent = new Intent(this, GpsService.class);
		bindService(gpsIntent, serviceConnection, Context.BIND_AUTO_CREATE);
	
		}

	public void saveMemoClick(View view) {
		// Get access to the edit Text fields
		EditText 
			editTitleTxt = (EditText) findViewById(R.id.et_Title), 
			editBodyTxt = (EditText) findViewById(R.id.et_Body);
		RadioButton 
			radius_a = (RadioButton) findViewById(R.id.rb_RadiusA), 
			radius_b = (RadioButton) findViewById(R.id.rb_RadiusB), 
			radius_c = (RadioButton) findViewById(R.id.rb_RadiusC);
		String 
			title = editTitleTxt.getText().toString(), 
			body = editBodyTxt.getText().toString();

		if (radius_a.isChecked()) rad = 25;
		else if (radius_b.isChecked()) rad = 50;
		else if (radius_c.isChecked()) rad = 100;
		else rad = 25;

		Memo memo = new Memo(title, body, lat, lon, rad);
		gpsService.updateNote(memo.toString());

		if (title != null && body != null) {
			gpsService.dbHelper.addMemo(memo);
		} else Toast.makeText(this, "Fields cannot be blank.", Toast.LENGTH_SHORT).show();
		
		unbindService(serviceConnection);
		finish();
	}
}
