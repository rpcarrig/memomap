package com.rpcarrig.memomapa;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class DatabaseHelper extends SQLiteOpenHelper {
	
	private static final int DATABASE_VERSION = 1;
	
	public static int 
		mKey = 0,
		fKey = 0;
	
	public static final String
		DATABASE_NAME ="databaseHelper",
	
		TABLE_NAME_MEMO = "Memo",
		M_COLUMN_NAME_DATE ="date",
		M_COLUMN_NAME_KEY ="key",
		M_COLUMN_NAME_LAT = "latitude",
		M_COLUMN_NAME_LON = "longitude",
		M_COLUMN_NAME_NOTE ="note",
		M_COLUMN_NAME_RADIUS = "radius",
		M_COLUMN_NAME_SHARE = "shared",
		M_COLUMN_NAME_TITLE ="title",
		
		TABLE_NAME_FAV = "Favorites",
		F_COLUMN_NAME_ADDR = "address",
		F_COLUMN_NAME_KEY = "key",
		F_COLUMN_NAME_LAT = "latitude",
		F_COLUMN_NAME_LON = "longitude",
		F_COLUMN_NAME_NAME = "name",

		SQL_CREATE_TABLE_FAV = "CREATE TABLE " 
				+ TABLE_NAME_FAV + " (" 
				+ F_COLUMN_NAME_KEY + " INTEGER, " 
				+ F_COLUMN_NAME_NAME + " TEXT, " 
				+ F_COLUMN_NAME_ADDR + " TEXT, " 
				+ F_COLUMN_NAME_LAT + " REAL, " 
				+ F_COLUMN_NAME_LON + " REAL);",
		
		SQL_CREATE_TABLE_MEMO =	"CREATE TABLE " +  
				TABLE_NAME_MEMO + " (" 
					+ M_COLUMN_NAME_KEY + " INTEGER, " 
					+ M_COLUMN_NAME_TITLE + " TEXT, " 
					+ M_COLUMN_NAME_NOTE + " TEXT, " 
					+ M_COLUMN_NAME_LAT + " REAL, " 
					+ M_COLUMN_NAME_LON  + " REAL, " 
					+ M_COLUMN_NAME_RADIUS + " REAL, "
					+ M_COLUMN_NAME_DATE + " TEXT, " 
					+ M_COLUMN_NAME_SHARE +" INTEGER);",
					
		SQL_DELETE_MEMO = "DROP TABLE IF EXISTS " + TABLE_NAME_MEMO,
		SQL_DELETE_FAV = "DROP TABLE IF EXISTS " + TABLE_NAME_FAV;

	//Constructor for the databaseHelper class
	public DatabaseHelper(Context context){
		super(context, DATABASE_NAME, null, DATABASE_VERSION);
	}

	@Override
	//creates the table
	public void onCreate(SQLiteDatabase db) {
		db.execSQL(SQL_CREATE_TABLE_MEMO);
		db.execSQL(SQL_CREATE_TABLE_FAV);
	}

	@Override
	//Not sure how to implement yet
	public void onUpgrade(SQLiteDatabase arg0, int arg1, int arg2) { }
	
	//Method that deletes the table Memo
	public void deleteAllMemos(SQLiteDatabase db){ db.execSQL(SQL_DELETE_MEMO); }
	
	//Method that deletes the table Favorites
	public void deleteAllFaves(SQLiteDatabase db){ db.execSQL(SQL_DELETE_FAV); }
	
	//Method that adds entry to the memo table
	//NOTE: you MUST pass a writable databaseHelper to this method
	//otherwise you will get an error
	public void addMemo(SQLiteDatabase db, String title, String note, double lat, double lon, double rad, String date, int share){
		
		//Create a new mapFragment of values, where column names are the keys
		ContentValues value = new ContentValues();
		value.put(M_COLUMN_NAME_KEY, mKey);
		value.put(M_COLUMN_NAME_TITLE, title);
		value.put(M_COLUMN_NAME_NOTE, note);
		value.put(M_COLUMN_NAME_LAT, lat);
		value.put(M_COLUMN_NAME_LON, lon);
		value.put(M_COLUMN_NAME_RADIUS, rad);
		value.put(M_COLUMN_NAME_DATE, date);
		value.put(M_COLUMN_NAME_SHARE, share);
		
		//Inserts the entry into the table
		db.insert(TABLE_NAME_MEMO, null, value);
	}
	
	//Method that adds entry to the databaseHelper
	//NOTE: you MUST pass a writable databaseHelper to this method
	//otherwise you will get an error
	public void addFave(SQLiteDatabase db, String name, String addr, double lat, double lon){
		
		//Create a new mapFragment of values, where column names are the keys
		ContentValues value = new ContentValues();
		value.put(F_COLUMN_NAME_KEY, fKey);
		value.put(F_COLUMN_NAME_NAME, name);
		value.put(F_COLUMN_NAME_ADDR, addr);
		value.put(F_COLUMN_NAME_LAT, lat);
		value.put(F_COLUMN_NAME_LON, lon);
	
		//Inserts the entry into the table
		db.insert(TABLE_NAME_FAV, null, value);
	}
	
	//Method that deletes an entry from the Memo table
	public void deleteMemo(SQLiteDatabase db, String[] selectionArgs){
		
		//Define the where part of the query
		String selection = M_COLUMN_NAME_KEY;
		//Delete the items
		db.delete(TABLE_NAME_MEMO, selection, selectionArgs);
	}
	
	//Method that deletes an entry from the Favorites table
	public void deleteFave(SQLiteDatabase db, String[] selectionArgs){
		
		//Define the where part of the query
		String selection = F_COLUMN_NAME_KEY;
		//Delete the items
		db.delete(TABLE_NAME_FAV, selection, selectionArgs);
	}
	
	//Method that edits an entry from the table Memo
	public void editMemo(SQLiteDatabase db, String[] selectionArgs, String update){
	
		//New value for note column
		ContentValues values = new ContentValues();
		values.put(M_COLUMN_NAME_NOTE, update);
		
		//Which row to update
		String selection = M_COLUMN_NAME_TITLE + " LIKE ?";
		
		//Update the entry
		@SuppressWarnings("unused")
		int i = db.update(TABLE_NAME_MEMO, values, selection, selectionArgs);
		System.out.println();
	}
	
	//Method that queries the table Memo
	public Cursor queryMemo(SQLiteDatabase db, String selection, String[] selectionArgs){
		
		//Define an array that says what columns will return
		String[] columns = { "rowid _id",M_COLUMN_NAME_KEY, M_COLUMN_NAME_TITLE, M_COLUMN_NAME_NOTE, M_COLUMN_NAME_LAT, M_COLUMN_NAME_LON, 
				M_COLUMN_NAME_RADIUS, M_COLUMN_NAME_DATE, M_COLUMN_NAME_SHARE};
		
		Cursor c = db.query(	
				TABLE_NAME_MEMO,		//The table to query
				columns,				//The columns to return
				selection,				//The columns for the WHERE clause
				selectionArgs,			//The values for the WHERE clause 
				null,					//don't group the rows
				null,					//don't filter by row groups
				null);					//use the default sort order
		return c;
	}
	
	//Method that queries the table Favorites
	public Cursor queryFav(SQLiteDatabase db, String selection, String[] selectionArgs){
		
		//Define an array that says what columns will return
		String[] columns = {F_COLUMN_NAME_KEY, F_COLUMN_NAME_NAME, F_COLUMN_NAME_LAT, F_COLUMN_NAME_LON};
		
		Cursor c = db.query(
				TABLE_NAME_FAV,			//The table to query
				columns,				//The columns to return
				selection,				//The columns for the WHERE clause
				selectionArgs,			//The values for the WHERE clause 
				null,					//don't group the rows
				null,					//dont filter by row groups
				null);					//use the default sort order
		return c;			
	}	
}