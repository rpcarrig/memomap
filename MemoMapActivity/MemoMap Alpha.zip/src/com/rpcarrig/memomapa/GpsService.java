package com.rpcarrig.memomapa;

import android.app.AlertDialog;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Binder;
import android.os.Bundle;
import android.os.IBinder;
import android.provider.Settings;
import android.support.v4.app.NotificationCompat;
import android.util.Log;

import com.google.android.gms.maps.model.LatLng;

public class GpsService extends Service implements LocationListener {
	private static final String 
		CLASS = "GpsService";
	
	boolean canGetLocation 		= false,
			isGpsEnabled 		= false,
			isNetworkEnabled 	= false;
	static double
		latitude,
		longitude;
	int		counter	= 0,
			mId		= 0;
	
	private Location location;
	private LocationManager locationManager;
	private NotificationCompat.Builder noteBuilder;
	private NotificationManager noteManager;	

	private final IBinder binder = new GpsBinder();
	
	private static final long
		MIN_DISTANCE_CHANGE		= 10,
		MIN_MS_BETWEEN_UPDATES	= 1000 * 60 * 1;
	public static boolean isMapMovable = true;
	
	public DatabaseHandler dbHelper;
	@SuppressWarnings("unused")
	private static SQLiteDatabase database;
	
	
	/**
	 * 
	 */
	
	public GpsService(){ }
	
	@Override
	public IBinder onBind(Intent intent) { return binder; }

	@Override
	public void onCreate() {
		Log.d(CLASS, "onCreate");
		super.onCreate();
		
		noteManager = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
		dbHelper = new DatabaseHandler(this);
		database = dbHelper.getWritableDatabase();
		
		startGps();
	}

	@Override
	public void onDestroy() {
		super.onDestroy();
		noteManager.cancel(0);
		
		if(locationManager != null){
			locationManager.removeUpdates(GpsService.this);
		}
	}
	
	@Override
	public void onLocationChanged(Location arg0) {
		Log.d(CLASS, "onLocationChanged");
		if (locationManager != null){
			location = locationManager.getLastKnownLocation(LocationManager.NETWORK_PROVIDER);
			if(location != null){
				latitude = location.getLatitude();
				longitude = location.getLongitude();
			}
		}
		updateNote(location.toString());
	}
		
	@Override
	public void onProviderDisabled(String arg0) { }

	@Override
	public void onProviderEnabled(String arg0) { }

	@Override
	public void onStatusChanged(String arg0, int arg1, Bundle arg2) { }
	
	/**
	 * 
	 */
	
	public boolean canGetLocation(){
		return this.canGetLocation;
	}
	
	public static void canMoveMap(){
		isMapMovable = true;
	}
	
	public static void cannotMoveMap(){
		isMapMovable = false;
	}
	
	public static double distanceTo(LatLng loc){
		float[] results = {0};
		Location.distanceBetween(latitude, longitude, loc.latitude, loc.longitude, results);
		Log.d("distanceTo", results.toString());
		return results[0];	
	}
	
	public double getLatitude(){
		if (location != null){ latitude = location.getLatitude(); }
		return latitude;
	}
	
	public double getLongitude(){
		if (location != null){ longitude = location.getLongitude(); }
		return longitude;
	}
	
	public boolean getMapMovability(){
		return isMapMovable;
	}
		
	public Location geoLocation(){	
		Log.d(CLASS, "geoLocation");
		if( !isGpsEnabled && !isNetworkEnabled){
			//no GPS or network
			Log.e(CONNECTIVITY_SERVICE, "no GPS or network");
		}
		else{
			this.canGetLocation = true;
			
			// If the network provider is available, get its location first.
			if(isNetworkEnabled){
				Log.d("geoLocation", "Network is enabled.");
				if (locationManager != null){
					location = locationManager.getLastKnownLocation(LocationManager.NETWORK_PROVIDER);
					if(location != null){
						latitude = location.getLatitude();
						longitude = location.getLongitude();
					}
				}
			}
			
			// If the GPS is also available, get coordinates using GPS services.
			if(isGpsEnabled){
				Log.d("geoLocation", "GPS is enabled.");
				if (locationManager != null){
					location = locationManager.getLastKnownLocation(LocationManager.GPS_PROVIDER);
					if(location != null){
						latitude = location.getLatitude();
						longitude = location.getLongitude();
					}
				}
			}
		}
		return location;
	}
	
	public void startGps(){
		Log.d(CLASS, "startGps");
		try{
			Log.d(CLASS, "trying to start GPS");
			locationManager	= (LocationManager)this.getSystemService(LOCATION_SERVICE);
			Log.d(CLASS, "locationManager set");
			isGpsEnabled		= locationManager.isProviderEnabled(LocationManager.GPS_PROVIDER);
			Log.d(CLASS, "isGpsEnabled");
			isNetworkEnabled	= locationManager.isProviderEnabled(LocationManager.NETWORK_PROVIDER);
			Log.d(CLASS, "isNetworkEnabled");
		
			locationManager.requestLocationUpdates(LocationManager.NETWORK_PROVIDER, MIN_MS_BETWEEN_UPDATES, MIN_DISTANCE_CHANGE, this);			
			Log.d(CLASS, "LocationUpdates requested");
		}
		catch (Exception e){
			e.printStackTrace();
			Log.e(NOTIFICATION_SERVICE, "GPS Start error");
		}
		
		Intent intent = new Intent(this, MainActivityFragments.class);
		PendingIntent pIntent = PendingIntent.getActivity(this, 0, intent, 0);
		noteBuilder =
		        new NotificationCompat.Builder(this)
		        .setContentTitle("MemoMap")
		        .setContentText("Searching for memos...")
		        .setContentIntent(pIntent)
		        //.setOngoing(true)
		        .setSmallIcon(R.drawable.ic_launcher);
		updateNote("GPS Started");
	}
	
	public void showSettingsAlert(){
		AlertDialog.Builder alertDialog = new AlertDialog.Builder(this);
		
		alertDialog.setMessage("Your GPS is not available. Please verify that GPS is enabled in your device's settings.");
		alertDialog.setTitle("GPS Error");
		
		alertDialog.setPositiveButton("Settings", new DialogInterface.OnClickListener() {
			@Override
			public void onClick(DialogInterface dialog, int which) {
				Intent intent = new Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS);
				startActivity(intent);
			}
		});
		alertDialog.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
			@Override
			public void onClick(DialogInterface dialog, int which) {
				dialog.cancel();
			}
		});
	}
	
	public void stopGps(){
		locationManager.removeUpdates(this);
	}
	
	public void updateNote(String ticker){
		if(location != null){
			String content = "[" + location.getLongitude() + ", " + location.getLatitude() + "]";
			noteBuilder.setContentText(content);
		}
		else{
			noteBuilder.setContentText("Acquiring location...");
		}
		noteBuilder.setTicker(ticker);
		noteManager.notify(0, noteBuilder.build());
	}	
	
	public class GpsBinder extends Binder{
		GpsService getService(){
			return GpsService.this;
		}
	}
}
