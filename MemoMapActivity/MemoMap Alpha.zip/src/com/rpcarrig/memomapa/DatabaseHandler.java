package com.rpcarrig.memomapa;

import java.util.ArrayList;
import java.util.List;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class DatabaseHandler extends SQLiteOpenHelper {
	private static final int
		DATABASE_VERSION = 1;
	public static final String
		DATABASE_NAME	= "memoMapDatabase",
		TABLE_MEMOS		= "memos",
		TABLE_FAVES		= "favorites",
		
		KEY_MID 		= "memo_id",
		KEY_MTITLE		= "memo_title",
		KEY_MBODY		= "memo_body",
		KEY_MDATE		= "memo_date",
		KEY_MLAT		= "memo_latitude",
		KEY_MLONG		= "memo_longitude",
		KEY_MRAD		= "memo_radius",
		
		KEY_FID			= "fave_id",
		KEY_FNAME		= "fave_name",
		KEY_FADDR		= "fave_address",
		KEY_FLAT		= "fave_latitude",
		KEY_FLONG		= "fave_longitude",
		KEY_FDATE		= "fave_date";
	
	private String 
		createMemoTable = "CREATE TABLE " + TABLE_MEMOS 
				+ "(" 
				+ KEY_MID 		+ " INTEGER PRIMARY KEY," 
				+ KEY_MTITLE 	+ " TEXT,"
				+ KEY_MBODY 	+ " TEXT,"
				+ KEY_MLAT 		+ " REAL,"
				+ KEY_MLONG 	+ " REAL,"
				+ KEY_MRAD 		+ " INTEGER,"
				+ KEY_MDATE 	+ " TEXT"
				+ ")",
		createFaveTable = "CREATE TABLE " + TABLE_FAVES
				+ "("
				+ KEY_FID		+ " INTEGER PRIMARY KEY,"
				+ KEY_FNAME		+ " TEXT,"
				+ KEY_FADDR		+ " TEXT,"
				+ KEY_FLAT		+ " REAL,"
				+ KEY_FLONG		+ " REAL,"
				+ KEY_FDATE		+ " TEXT"
				+ ")",
		selectQuery 	= "SELECT  * FROM ";
	
	public DatabaseHandler(Context context) {
		super(context, DATABASE_NAME, null, DATABASE_VERSION);
	}

	@Override
	public void onCreate(SQLiteDatabase db) {
		db.execSQL(createMemoTable);
		db.execSQL(createFaveTable);
	}

	@Override
	public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
		deleteAllFaves();
		deleteAllMemos();
		onCreate(db);
	}
	
	
	// ALL CRUD OPERATIONS BELOW
	
	public void addFave(Favorite fave) {
		ContentValues values = new ContentValues();
		values.put(KEY_FADDR, fave.getFaveAddress());
		values.put(KEY_FLAT, fave.getLatitude());
		values.put(KEY_FLONG, fave.getLongitude());
		values.put(KEY_FNAME, fave.getFaveName());
		
		SQLiteDatabase db = getWritableDatabase();
		db.insert(TABLE_FAVES, null, values);
		db.close();
	}
	
	public void addMemo(Memo memo) {
		ContentValues values = new ContentValues();
		values.put(KEY_MLAT, 	memo.getLatitude());
		values.put(KEY_MLONG, 	memo.getLongitude());
		values.put(KEY_MTITLE, 	memo.getMemoTitle());
		values.put(KEY_MBODY, 	memo.getMemoBody());
		values.put(KEY_MDATE, 	memo.getMemoDate());
		values.put(KEY_MRAD, 	memo.getRadius());
		
		SQLiteDatabase db = getWritableDatabase();
		db.insert(TABLE_MEMOS, null, values);
		db.close();
	}
	
	public void deleteFave(Favorite fave) {
		String
			table		= TABLE_FAVES,
			selection 	= KEY_FID + "=?";
		String[] whereArgs = { String.valueOf(fave.getId()) };
		
		SQLiteDatabase db = getWritableDatabase();
		db.delete(table, selection, whereArgs);
		db.close();		
	}
	
	public void deleteMemo(Memo memo) {
		String
			table		= TABLE_MEMOS,
			selection 	= KEY_MID + "=?";
		String[] whereArgs = { String.valueOf(memo.getId()) };
		
		SQLiteDatabase db = getWritableDatabase();
		db.delete(table, selection, whereArgs);
		db.close();
	}
	
	public void deleteAllFaves(){
		getWritableDatabase().execSQL("DROP TABLE IF EXISTS " + TABLE_FAVES);
	}
	
	public void deleteAllMemos(){
		getWritableDatabase().execSQL("DROP TABLE IF EXISTS " + TABLE_MEMOS);
	}
	
	public Favorite getFave(int id) {
		String
			table		= TABLE_FAVES,
			selection 	= KEY_FID + "=?";
		String[] 
			columns 	= new String[]{
							KEY_FID,
							KEY_FNAME,
							KEY_FADDR,
							KEY_FLAT,
							KEY_FLONG,
							KEY_FDATE},
			args		= new String[]{	String.valueOf(id) };
		
		Cursor cursor = getWritableDatabase()
				.query(table, columns, selection, args, null, null, null);
		if (cursor != null) cursor.moveToFirst();
		
		Favorite fave = new Favorite(
				Integer.parseInt(cursor.getString(0)),
				cursor.getString(1),
				cursor.getString(2),
				Double.parseDouble(cursor.getString(3)),
				Double.parseDouble(cursor.getString(4)));
		cursor.close();
		return fave;
	}
	
	public Cursor queryFaves(SQLiteDatabase db){
		String
			table		= TABLE_FAVES,
			selection 	= KEY_FID + "=?";
		String[] columns = new String[]{
							KEY_FID,
							KEY_FNAME,
							KEY_FADDR,
							KEY_FLAT,
							KEY_FLONG,
							KEY_FDATE};
		return db.query(table, columns, selection, null, null, null, null);		
	}
	
	public Cursor queryMemo(SQLiteDatabase db, String[] selectionArgs){
		String table	= TABLE_MEMOS,
			selection 	= KEY_MID + "=?";
		String[] 
			columns 	= new String[]{
							KEY_MID,
							KEY_MTITLE,
							KEY_MBODY,
							KEY_MDATE,
							KEY_MLAT,
							KEY_MLONG,
							KEY_MRAD };
		return db.query(table, columns, selection, selectionArgs, null, null, null);
	}
	
	public Memo getMemo(int id) {
		String
			table		= TABLE_MEMOS,
			selection 	= KEY_MID + "=?";
		String[] 
			columns 	= new String[]{
							KEY_MID,
							KEY_MTITLE,
							KEY_MBODY,
							KEY_MDATE,
							KEY_MLAT,
							KEY_MLONG,
							KEY_MRAD },
			args		= new String[]{	String.valueOf(id) };
		Cursor cursor = getWritableDatabase()
				.query(table, columns, selection, args, null, null, null);
		if (cursor != null) cursor.moveToFirst();
		
		Memo memo = new Memo(
				Integer.parseInt(cursor.getString(0)),
				cursor.getString(1),
				cursor.getString(2),
				Double.parseDouble(cursor.getString(3)),
				Double.parseDouble(cursor.getString(4)),
				Integer.parseInt(cursor.getString(5)));
		cursor.close();
		return memo;
	}
	
	public List<Favorite> getAllFaves() {
		Cursor cursor = getWritableDatabase().rawQuery(selectQuery + TABLE_FAVES, null);
		List<Favorite> faveList = new ArrayList<Favorite>();
		if(cursor.moveToFirst()){
			do {
				Favorite fave = new Favorite(
						Integer.parseInt(cursor.getString(0)),
						cursor.getString(1),
						cursor.getString(2),
						Double.parseDouble(cursor.getString(3)),
						Double.parseDouble(cursor.getString(4)));
				faveList.add(fave);
			} while (cursor.moveToNext());
		}
		cursor.close();	
		return faveList;
	}
	
	public List<Memo> getAllMemos() {
		Cursor cursor = getWritableDatabase().rawQuery(selectQuery + TABLE_MEMOS, null);
		List<Memo> memoList	= new ArrayList<Memo>();
		if(cursor.moveToFirst()){
			do {
				Memo memo = new Memo(
						Integer.parseInt(cursor.getString(0)),
						cursor.getString(1),
						cursor.getString(2),
						Double.parseDouble(cursor.getString(3)),
						Double.parseDouble(cursor.getString(4)),
						Integer.parseInt(cursor.getString(5)));
				memoList.add(memo);
			} while (cursor.moveToNext());
		}
		cursor.close();
		return memoList;
	}
	
	public int getFaveCount() {
		Cursor cursor = getWritableDatabase().rawQuery(selectQuery + TABLE_FAVES, null);
		
		cursor.close();
		return cursor.getCount();
	}
	
	public int getMemoCount() {
		Cursor cursor = getWritableDatabase().rawQuery(selectQuery + TABLE_MEMOS, null);
		
		cursor.close();
		return cursor.getCount();
	}
	
	public int updateFave(Favorite fave) {
		ContentValues values = new ContentValues();
		values.put(KEY_FADDR, fave.getFaveAddress());
		values.put(KEY_FLAT,  fave.getLatitude());
		values.put(KEY_FLONG, fave.getLongitude());
		values.put(KEY_FNAME, fave.getFaveName());
		values.put(KEY_FDATE, fave.getFaveDate());
		
		String
			table		= TABLE_FAVES,
			selection 	= KEY_FID + "=?";
		String[] whereArgs = { String.valueOf(fave.getId()) };	
		return getWritableDatabase().update(table, values, selection, whereArgs);		
	}
	
	public int updateMemo(Memo memo) {
		ContentValues values = new ContentValues();
		values.put(KEY_MLAT, 	memo.getLatitude());
		values.put(KEY_MLONG, 	memo.getLongitude());
		values.put(KEY_MTITLE, 	memo.getMemoTitle());
		values.put(KEY_MBODY, 	memo.getMemoBody());
		values.put(KEY_MRAD, 	memo.getRadius());
		values.put(KEY_MDATE, 	memo.getMemoDate());
		
		String
			table		= TABLE_MEMOS,
			selection 	= KEY_MID + "=?";
		String[] whereArgs = { String.valueOf(memo.getId()) };
		return getWritableDatabase().update(table, values, selection, whereArgs);
	}
}
