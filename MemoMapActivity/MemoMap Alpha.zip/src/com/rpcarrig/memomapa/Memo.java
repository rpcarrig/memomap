package com.rpcarrig.memomapa;

import android.text.format.Time;

public class Memo {
	int
		id,
		radius;
	String
		memoBody,
		memoDate,
		memoTitle;
	double
		latitude,
		longitude;
		
	public Memo(){ }
	
	public Memo(String title, String body, double lat, double lon, int rad){
		latitude 	= lat;
		longitude 	= lon;
		radius 		= rad;
		memoBody 	= body;
		memoDate 	= new Time(Time.getCurrentTimezone()).toString();
		memoTitle 	= title;
	}
	
	public Memo(int i, String title, String body, double lat, double lon, int rad){
		id			= i;
		latitude 	= lat;
		longitude 	= lon;
		radius 		= rad;
		memoBody 	= body;
		memoDate 	= new Time(Time.getCurrentTimezone()).toString();
		memoTitle 	= title;
	}
	
	public int getId()				{ return id; 			}	
	public int getRadius()			{ return radius; 		}
	public double getLatitude()		{ return latitude; 		}
	public double getLongitude()	{ return longitude; 	}
	public String getMemoBody()		{ return memoBody; 		}
	public String getMemoDate()		{ return memoDate; 		}
	public String getMemoTitle()	{ return memoTitle; 	}
	
	public void setId(int i)			{ id = i; 			}
	public void setRadius(int r)		{ radius = r; 		}
	public void setMemoBody(String b)	{ memoBody = b; 	}
	public void setMemoDate(String d)	{ memoDate = d; 	}
	public void setMemoTitle(String t)	{ memoTitle = t; 	}
	public void setLatitude(double l)	{ latitude = l;		}
	public void setLongitude(double l)	{ longitude = l;	}
	
	
	public String toString(){
		return "[" + memoTitle + "] " + memoBody + " -- (" + longitude + ", " + latitude + ")";
	}
}
